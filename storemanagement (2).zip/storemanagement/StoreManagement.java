import java.sql.*;
import java.util.Scanner;

public class StoreManagement {
    private static final String ADMIN_ID = "abhinav";
    private static final String ADMIN_PASSWORD = "1234";
    private static final String DATABASE_URL = "jdbc:mysql://localhost:3306/StoreManagementDB";
    private static final String USER = "root";
    private static final String PASSWORD = "creta6218";
    private static final int MAX_PRODUCTS = 100;
    private static Product[] products = new Product[MAX_PRODUCTS];
    private static int productCount = 0;

    public static void main(String[] args) {
        initializeDatabase();
        System.out.println("Welcome to the Store Management System");
        System.out.print("Enter Admin ID: ");
        String adminId = getUserInputString();
        System.out.print("Enter Admin Password: ");
        String adminPassword = getUserInputString();

        if (isValidAdmin(adminId, adminPassword)) {
            runStoreManagementSystem();
        } else {
            System.out.println("Invalid admin credentials. Exiting...");
        }
    }

    private static void initializeDatabase() {
        try (Connection connection = DriverManager.getConnection(DATABASE_URL, USER, PASSWORD)) {
            String createTableQuery = "CREATE TABLE IF NOT EXISTS products (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "name VARCHAR(255) NOT NULL," +
                    "price DOUBLE NOT NULL," +
                    "quantity INT NOT NULL," +
                    "can_bargain BOOLEAN NOT NULL," +
                    "festival_offer BOOLEAN NOT NULL," +
                    "bargain_discount DOUBLE NOT NULL," +
                    "festival_discount DOUBLE NOT NULL," +
                    "selling_price DOUBLE NOT NULL)";
            try (Statement statement = connection.createStatement()) {
                statement.execute(createTableQuery);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void runStoreManagementSystem() {
        while (true) {
            System.out.println("Store Management System");
            System.out.println("1. Add Product\n2. View Inventory\n3. Sell Product\n4. Exit");
            System.out.print("Enter your choice: ");

            int choice = getUserInput();

            switch (choice) {
                case 1:
                    addProductForm();
                    break;
                case 2:
                    viewInventory();
                    break;
                case 3:
                    sellProduct();
                    break;
                case 4:
                    System.out.println("Exiting the Store Management System. Goodbye!");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static boolean isValidAdmin(String adminId, String adminPassword) {
        return adminId.equals(ADMIN_ID) && adminPassword.equals(ADMIN_PASSWORD);
    }

    private static void addProductForm() {
        System.out.print("Enter product name: ");
        String name = getUserInputString();

        System.out.print("Enter product price: ₹");
        double productPrice = getUserInputDouble();

        System.out.print("Enter initial quantity in stock: ");
        int quantity = getUserInputInt();

        System.out.print("Can customers bargain for this product? (true/false): ");
        boolean canBargain = getUserInputBoolean();

        double bargainDiscountPercentage = 0;
        if (canBargain) {
            System.out.print("Enter percentage discount for bargaining (e.g., 5 for 5%): ");
            bargainDiscountPercentage = getUserInputDouble();
        }

        System.out.print("Is there a festival offer? (true/false): ");
        boolean festivalOffer = getUserInputBoolean();

        double festivalOfferPercentage = 0;
        if (festivalOffer) {
            System.out.print("Enter percentage discount for festival offer (e.g., 10 for 10%): ");
            festivalOfferPercentage = getUserInputDouble();
        }

        double retailPrice = productPrice; // Retail price initially set to product price
        double sellingPrice = calculateSellingPrice(productPrice, canBargain, bargainDiscountPercentage,
                festivalOffer, festivalOfferPercentage);

        // Add the product to the array
        Product newProduct = new Product(name, productPrice, quantity, canBargain, festivalOffer,
                bargainDiscountPercentage, festivalOfferPercentage, retailPrice, sellingPrice);
        products[productCount] = newProduct;
        productCount++;

        // Add the product to the database
        addProductToDatabase(newProduct);

        System.out.println("Product added successfully");
    }

    private static void viewInventory() {
        retrieveProductsFromDatabase();
    
        if (productCount == 0) {
            System.out.println("No products in the inventory");
        } else {
            System.out.println("-----------------------------------------------------------------------------------------------------------------");
            System.out.printf("| %-5s | %-20s | %-15s | %-8s | %-12s | %-15s | %-15s |\n", "ID", "Name", "Product Price", "Quantity", "Bargain", "Festival Offer", "Selling Price");
            System.out.println("-----------------------------------------------------------------------------------------------------------------");
            for (int i = 0; i < productCount; i++) {
                Product product = products[i];
                System.out.printf("| %-5d | %-20s | %-15s | %-8d | %-12s | %-15s | %-15s |\n", i + 1, product.name, "₹" + product.productPrice,
                        product.quantity, product.canBargain ? "Yes" : "No", product.festivalOffer ? "Yes" : "No", "₹" + product.sellingPrice);
            }
            System.out.println("-----------------------------------------------------------------------------------------------------------------");
        }
    }
    

    private static void sellProduct() {
        if (productCount == 0) {
            System.out.println("No products in the inventory. Cannot sell.");
            return;
        }

        System.out.print("Enter the name of the product to sell: ");
        String productName = getUserInputString();

        Product productToSell = findProductByName(productName);

        if (productToSell == null) {
            System.out.println("Product not found in the inventory. Cannot sell.");
            return;
        }

        System.out.print("Enter the quantity to sell: ");
        int quantityToSell = getUserInputInt();

        if (quantityToSell > productToSell.quantity) {
            System.out.println("Insufficient quantity in stock. Cannot sell.");
            return;
        }

        // Update quantity and selling price after applying discounts
        productToSell.quantity -= quantityToSell;
        double sellingPrice = productToSell.sellingPrice * quantityToSell;

        System.out.println("Product sold successfully. Total selling price: ₹" + sellingPrice);
        updateProductInDatabase(productToSell);
    }

    private static void addProductToDatabase(Product product) {
        try (Connection connection = DriverManager.getConnection(DATABASE_URL, USER, PASSWORD)) {
            String insertQuery = "INSERT INTO products (name, price, quantity, can_bargain, festival_offer, " +
                    "bargain_discount, festival_discount, selling_price) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
                preparedStatement.setString(1, product.name);
                preparedStatement.setDouble(2, product.productPrice);
                preparedStatement.setInt(3, product.quantity);
                preparedStatement.setBoolean(4, product.canBargain);
                preparedStatement.setBoolean(5, product.festivalOffer);
                preparedStatement.setDouble(6, product.bargainDiscountPercentage);
                preparedStatement.setDouble(7, product.festivalOfferPercentage);
                preparedStatement.setDouble(8, product.sellingPrice);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void retrieveProductsFromDatabase() {
        productCount = 0;
        try (Connection connection = DriverManager.getConnection(DATABASE_URL, USER, PASSWORD)) {
            String selectQuery = "SELECT * FROM products";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(selectQuery)) {
                while (resultSet.next() && productCount < MAX_PRODUCTS) {
                    Product product = new Product(
                            resultSet.getString("name"),
                            resultSet.getDouble("price"),
                            resultSet.getInt("quantity"),
                            resultSet.getBoolean("can_bargain"),
                            resultSet.getBoolean("festival_offer"),
                            resultSet.getDouble("bargain_discount"),
                            resultSet.getDouble("festival_discount"),
                            0, // Retail price initially set to 0
                            resultSet.getDouble("selling_price")
                    );
                    products[productCount] = product;
                    productCount++;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateProductInDatabase(Product product) {
        try (Connection connection = DriverManager.getConnection(DATABASE_URL, USER, PASSWORD)) {
            String updateQuery = "UPDATE products SET quantity = ? WHERE name = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {
                preparedStatement.setInt(1, product.quantity);
                preparedStatement.setString(2, product.name);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static double calculateSellingPrice(double productPrice, boolean canBargain,
                                                 double bargainDiscountPercentage, boolean festivalOffer,
                                                 double festivalOfferPercentage) {
        double sellingPrice = productPrice; // Selling price initially set to product price

        // Apply discounts for bargaining and festival offer
        if (canBargain && bargainDiscountPercentage > 0) {
            sellingPrice -= (sellingPrice * bargainDiscountPercentage / 100);
        }

        if (festivalOffer && festivalOfferPercentage > 0) {
            sellingPrice -= (productPrice * festivalOfferPercentage / 100);
        }

        return sellingPrice;
    }

    private static int getUserInput() {
        int input = -1;
        boolean isValidInput = false;
        while (!isValidInput) {
            try {
                Scanner scanner = new Scanner(System.in);
                input = scanner.nextInt();
                isValidInput = true;
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a valid integer.");
            }
        }
        return input;
    }

    private static double getUserInputDouble() {
        double input = -1;
        boolean isValidInput = false;
        while (!isValidInput) {
            try {
                Scanner scanner = new Scanner(System.in);
                input = scanner.nextDouble();
                isValidInput = true;
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a valid double.");
            }
        }
        return input;
    }

    private static int getUserInputInt() {
        int input = -1;
        boolean isValidInput = false;
        while (!isValidInput) {
            try {
                Scanner scanner = new Scanner(System.in);
                input = scanner.nextInt();
                isValidInput = true;
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a valid integer.");
            }
        }
        return input;
    }

    private static String getUserInputString() {
        String input = "";
        boolean isValidInput = false;
        while (!isValidInput) {
            try {
                Scanner scanner = new Scanner(System.in);
                input = scanner.nextLine();
                isValidInput = true;
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a valid string.");
            }
        }
        return input;
    }

    private static boolean getUserInputBoolean() {
        boolean input = false;
        boolean isValidInput = false;
        while (!isValidInput) {
            try {
                Scanner scanner = new Scanner(System.in);
                input = scanner.nextBoolean();
                isValidInput = true;
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a valid boolean (true/false).");
            }
        }
        return input;
    }

    private static Product findProductByName(String name) {
        for (int i = 0; i < productCount; i++) {
            if (products[i].name.equalsIgnoreCase(name)) {
                return products[i];
            }
        }
        return null;
    }

    static class Product {
        private String name;
        private double productPrice;
        private int quantity;
        private boolean canBargain;
        private boolean festivalOffer;
        private double bargainDiscountPercentage;
        private double festivalOfferPercentage;
        private double retailPrice;
        private double sellingPrice;

        public Product(String name, double productPrice, int quantity, boolean canBargain,
                       boolean festivalOffer, double bargainDiscountPercentage,
                       double festivalOfferPercentage, double retailPrice, double sellingPrice) {
            this.name = name;
            this.productPrice = productPrice;
            this.quantity = quantity;
            this.canBargain = canBargain;
            this.festivalOffer = festivalOffer;
            this.bargainDiscountPercentage = bargainDiscountPercentage;
            this.festivalOfferPercentage = festivalOfferPercentage;
            this.retailPrice = retailPrice;
            this.sellingPrice = sellingPrice;
        }

        @Override
        public String toString() {
            return "Name: " + name + ", Product Price: ₹" + productPrice + ", Quantity: " + quantity +
                    ", Can Bargain: " + canBargain + ", Festival Offer: " + festivalOffer +
                    ", Bargain Discount: " + bargainDiscountPercentage + "%, Festival Offer Discount: " +
                    festivalOfferPercentage + "%, Retail Price: ₹" + retailPrice +
                    ", Selling Price: ₹" + sellingPrice;
        }
    }
}